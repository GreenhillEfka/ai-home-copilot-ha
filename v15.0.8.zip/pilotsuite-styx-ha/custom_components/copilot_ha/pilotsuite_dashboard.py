from __future__ import annotations

import logging
from pathlib import Path
import shutil

from homeassistant.components import persistent_notification
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.util import dt as dt_util

from .const import (
    CONF_DEVLOG_PUSH_ENABLED,
    CONF_MEDIA_MUSIC_PLAYERS,
    CONF_MEDIA_TV_PLAYERS,
    CONF_PILOTSUITE_SHOW_SAFETY_BACKUP_BUTTONS,
    CONF_PILOTSUITE_SHOW_DEV_SURFACE_BUTTONS,
    CONF_PILOTSUITE_SHOW_GRAPH_BRIDGE_BUTTONS,
    DEFAULT_DEVLOG_PUSH_ENABLED,
    DEFAULT_MEDIA_MUSIC_PLAYERS,
    DEFAULT_MEDIA_TV_PLAYERS,
    DEFAULT_PILOTSUITE_SHOW_SAFETY_BACKUP_BUTTONS,
    DEFAULT_PILOTSUITE_SHOW_DEV_SURFACE_BUTTONS,
    DEFAULT_PILOTSUITE_SHOW_GRAPH_BRIDGE_BUTTONS,
    LEGACY_DASHBOARD_DIR,
    PRIMARY_DASHBOARD_DIR,
)
# DEPRECATED: v1 - prefer v2
# from .habitus_zones_store import async_get_zones
from .habitus_zones_store_v2 import async_get_zones_v2
from .pilotsuite_dashboard_store import PilotSuiteDashboardState, async_get_state, async_set_state

_LOGGER = logging.getLogger(__name__)


def _write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def _copy(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)


def _resolve_entity(hass: HomeAssistant, candidates: list[str]) -> str | None:
    """Pick first existing entity_id from candidates."""
    for entity_id in candidates:
        if hass.states.get(entity_id) is not None:
            return entity_id
    return None


def _compact_entities(values: list[str | None]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if not value:
            continue
        if value in seen:
            continue
        seen.add(value)
        result.append(value)
    return result


def _existing_entities(hass: HomeAssistant, entity_ids: list[str]) -> list[str]:
    return [entity_id for entity_id in entity_ids if hass.states.get(entity_id) is not None]


def _entities_card(title: str, entities: list[str]) -> str:
    clean_entities = [eid for eid in entities if isinstance(eid, str) and eid.strip()]
    lines = [
        "      - type: entities",
        f"        title: {_yaml_q(title)}",
        "        show_header_toggle: false",
        "        entities:",
    ]
    if not clean_entities:
        lines.append("          - type: section")
        lines.append("            label: (no entities)")
    else:
        for eid in clean_entities:
            lines.append(f"          - entity: {eid}")
    return "\n".join(lines)


def _markdown_card(title: str, content: str) -> str:
    return (
        "      - type: markdown\n"
        f"        title: {_yaml_q(title)}\n"
        "        content: |\n"
        + "\n".join(["          " + ln for ln in content.strip().splitlines()])
        + "\n"
    )


def _grid_card(cards: list[str], *, columns: int = 2) -> str:
    # cards entries are already full YAML card snippets starting with "      - type: ...".
    # Convert them into nested cards under a grid card.
    nested = []
    for c in cards:
        # strip leading list marker indentation (6 spaces + '- ')
        lines = c.splitlines()
        if not lines:
            continue
        if lines[0].startswith("      - "):
            lines[0] = "        - " + lines[0][8:]
        else:
            lines[0] = "        - " + lines[0].lstrip()
        for i in range(1, len(lines)):
            if lines[i].startswith("        "):
                # increase indentation by 2 to align under grid.cards
                lines[i] = "  " + lines[i]
            else:
                lines[i] = "          " + lines[i].lstrip()
        nested.append("\n".join(lines))

    return (
        "      - type: grid\n"
        f"        columns: {int(columns)}\n"
        "        square: false\n"
        "        cards:\n"
        + "\n\n".join(nested)
        + "\n"
    )


def _view(title: str, path: str, icon: str, cards_yaml: str) -> str:
    return (
        f"  - title: {_yaml_q(title)}\n"
        f"    path: {_yaml_q(path)}\n"
        f"    icon: {icon}\n"
        f"    cards:\n"
        f"{cards_yaml}\n"
    )


def _yaml_q(value: str) -> str:
    escaped = str(value).replace("\\", "\\\\").replace("\"", "\\\"")
    return f"\"{escaped}\""


async def async_generate_pilotsuite_dashboard(
    hass: HomeAssistant,
    entry: ConfigEntry,
    *,
    notify: bool = True,
) -> Path:
    """Generate a governance-first Lovelace YAML dashboard.

    PilotSuite goal: give operators a ready-to-import dashboard *without* auto-modifying Lovelace.
    """

    cfg = entry.data | entry.options

    zones = await async_get_zones_v2(hass, entry.entry_id)
    has_zones = len(zones) > 0

    music_players = cfg.get(CONF_MEDIA_MUSIC_PLAYERS, DEFAULT_MEDIA_MUSIC_PLAYERS)
    tv_players = cfg.get(CONF_MEDIA_TV_PLAYERS, DEFAULT_MEDIA_TV_PLAYERS)
    has_media = bool(music_players) or bool(tv_players)

    devlogs_enabled = bool(cfg.get(CONF_DEVLOG_PUSH_ENABLED, DEFAULT_DEVLOG_PUSH_ENABLED))

    # Known entity_ids from this integration (stable unique_ids).
    overview_entities = _compact_entities([
        _resolve_entity(
            hass,
            ["binary_sensor.copilot_ha_online", "binary_sensor.pilotsuite_styx_online"],
        ),
        _resolve_entity(
            hass,
            ["sensor.copilot_ha_version", "sensor.pilotsuite_styx_version"],
        ),
        _resolve_entity(
            hass,
            ["sensor.copilot_ha_core_api_v1", "sensor.pilotsuite_core_api_v1"],
        ),
        _resolve_entity(
            hass,
            ["sensor.copilot_ha_habitus_zones_count", "sensor.pilotsuite_habitus_zones_count"],
        ),
    ])

    # Systemressourcen (optional; nur anzeigen, wenn vorhanden)
    resource_candidates = [
        # system_monitor (typisch)
        "sensor.processor_use",
        "sensor.memory_use_percent",
        "sensor.disk_use_percent",
        "sensor.load_1m",
        "sensor.load_5m",
        "sensor.load_15m",
        # alternative naming (je nach Setup)
        "sensor.cpu_use",
        "sensor.ram_use_percent",
        "sensor.system_monitor_processor_use",
        "sensor.system_monitor_memory_use_percent",
    ]
    resource_entities = [e for e in resource_candidates if hass.states.get(e) is not None]

    operations_entities = _compact_entities([
        _resolve_entity(
            hass,
            ["button.copilot_ha_reload_config_entry", "button.pilotsuite_reload_config_entry"],
        ),
        _resolve_entity(
            hass,
            ["button.copilot_ha_forwarder_status", "button.pilotsuite_forwarder_status"],
        ),
        _resolve_entity(
            hass,
            ["button.copilot_ha_fetch_ha_errors", "button.pilotsuite_fetch_ha_errors"],
        ),
    ])

    show_safety_backup = bool(
        cfg.get(
            CONF_PILOTSUITE_SHOW_SAFETY_BACKUP_BUTTONS,
            DEFAULT_PILOTSUITE_SHOW_SAFETY_BACKUP_BUTTONS,
        )
    )
    if show_safety_backup:
        operations_entities.extend(
            _existing_entities(
                hass,
                [
                "button.copilot_ha_safety_backup_create",
                "button.copilot_ha_safety_backup_status",
                ],
            )
        )

    show_dev_surface = bool(
        cfg.get(
            CONF_PILOTSUITE_SHOW_DEV_SURFACE_BUTTONS,
            DEFAULT_PILOTSUITE_SHOW_DEV_SURFACE_BUTTONS,
        )
    )
    if show_dev_surface:
        operations_entities.extend(
            _existing_entities(
                hass,
                [
                "button.copilot_ha_ping_core",
                "button.copilot_ha_enable_debug_30m",
                "button.copilot_ha_disable_debug",
                "button.copilot_ha_clear_error_digest",
                ],
            )
        )

    show_graph_bridge = bool(
        cfg.get(
            CONF_PILOTSUITE_SHOW_GRAPH_BRIDGE_BUTTONS,
            DEFAULT_PILOTSUITE_SHOW_GRAPH_BRIDGE_BUTTONS,
        )
    )
    if show_graph_bridge:
        operations_entities.extend(
            _existing_entities(
                hass,
                [
                "button.copilot_ha_preview_graph_candidates",
                "button.copilot_ha_offer_graph_candidates",
                ],
            )
        )

    operations_entities.extend(
        _existing_entities(
            hass,
            [
            "button.copilot_ha_generate_config_snapshot",
            "button.copilot_ha_download_config_snapshot",
            ],
        )
    )
    operations_entities = _compact_entities(operations_entities)

    # Generate reicht: die Dashboards referenzieren jeweils die stabile `*_latest.yaml` Datei.
    # Download/Publish ist nur für /local-Downloads nötig.
    dashboards_entities = _compact_entities([
        _resolve_entity(
            hass,
            ["button.copilot_ha_generate_pilotsuite_dashboard", "button.pilotsuite_generate_pilotsuite_dashboard"],
        ),
        _resolve_entity(
            hass,
            ["button.copilot_ha_generate_habitus_dashboard", "button.pilotsuite_generate_habitus_dashboard"],
        ),
    ])

    core_entities = _compact_entities([
        _resolve_entity(
            hass,
            ["button.copilot_ha_fetch_core_capabilities", "button.pilotsuite_fetch_core_capabilities"],
        ),
        _resolve_entity(
            hass,
            ["button.copilot_ha_fetch_core_events", "button.pilotsuite_fetch_core_events"],
        ),
        _resolve_entity(
            hass,
            ["button.copilot_ha_fetch_core_graph_state", "button.pilotsuite_fetch_core_graph_state"],
        ),
    ])

    habitus_entities = _existing_entities(
        hass,
        [
        "button.copilot_ha_validate_habitus_zones",
        ],
    )

    media_entities = _existing_entities(
        hass,
        [
        "sensor.copilot_ha_music_now_playing",
        "sensor.copilot_ha_music_primary_area",
        "sensor.copilot_ha_music_active_count",
        "sensor.copilot_ha_tv_primary_area",
        "sensor.copilot_ha_tv_source",
        "sensor.copilot_ha_tv_active_count",
        ],
    )

    # Dev push buttons are disabled-by-default; keep the read-only fetch visible.
    # Dev/Fehler-Surface: hier bündeln wir die "sichtbar machen" Buttons.
    dev_entities = _existing_entities(
        hass,
        [
        "button.copilot_ha_fetch_ha_errors",
        "button.copilot_ha_devlogs_fetch",
        "button.copilot_ha_forwarder_status",
        "button.copilot_ha_fetch_core_events",
        "button.copilot_ha_fetch_core_capabilities",
        ],
    )

    views: list[str] = []

    host = str(cfg.get("host") or "homeassistant.local")
    port = int(cfg.get("port") or 8909)
    if host.startswith("http://") or host.startswith("https://"):
        core_base = f"{host}:{port}" if ":" not in host.split("//", 1)[1] else host
    else:
        core_base = f"http://{host}:{port}"

    # ── TAB 1: STYX ──────────────────────────────────────────────────────
    # Brain visualization, Chat, Suggestions, Automations, Error log
    styx_cards: list[str] = []

    # Brain Graph (iframe from Core)
    styx_cards.append(
        "      - type: iframe\n"
        f"        url: {core_base}/api/v1/styx/dashboard\n"
        "        title: \"Neuronales Netzwerk\"\n"
        "        aspect_ratio: \"16:9\"\n"
    )

    # Mood + Neurons side by side
    mood_card = (
        "      - type: custom:styx-mood-card\n"
        "        entity: sensor.copilot_ha_mood\n"
        "        title: Stimmung\n"
        "        show_emotions: 5\n"
    )
    neurons_card = (
        "      - type: custom:styx-brain-card\n"
        "        entity: sensor.copilot_ha_brain_graph_nodes\n"
        "        title: Brain Graph\n"
    )
    styx_cards.append(_grid_card([mood_card, neurons_card], columns=2))

    # Chat Interface
    styx_cards.append(
        "      - type: custom:styx-chat-card\n"
        "        title: Styx Chat\n"
        f"        core_url: {_yaml_q(core_base)}\n"
        "        max_messages: 50\n"
        "        show_history: true\n"
    )

    # Suggestions
    styx_cards.append(
        "      - type: custom:styx-suggestions-card\n"
        "        title: KI-Vorschlaege\n"
        f"        core_url: {_yaml_q(core_base)}\n"
        "        max_suggestions: 10\n"
        "        show_actions: true\n"
    )

    # Error Log + Repair Suggestions
    styx_cards.append(
        "      - type: custom:styx-error-card\n"
        "        title: Fehler & Reparatur\n"
        f"        core_url: {_yaml_q(core_base)}\n"
        "        hours: 24\n"
        "        max_errors: 20\n"
    )

    # Automations summary (entities card with existing HA automations)
    automation_entities = _existing_entities(
        hass,
        [
            "sensor.copilot_ha_predictive_automation",
            "sensor.copilot_ha_zone_scenes",
        ],
    )
    if automation_entities:
        styx_cards.append(_entities_card("Automatisierungen", automation_entities))

    views.append(_view("Styx", "styx", "mdi:brain", "\n\n".join(styx_cards)))

    # ── TAB 2: HAUSHALTSUEBERSICHT ────────────────────────────────────────
    # Household overview, zones, weather, prices, alerts, notifications
    household_cards: list[str] = []

    # Household Overview Card
    household_cards.append(
        "      - type: custom:styx-household-card\n"
        "        title: Haushaltsuebersicht\n"
        "        show_weather: true\n"
        "        show_prices: true\n"
        "        show_alerts: true\n"
        "        show_zones: true\n"
    )

    # Status + Operations grid
    grid_cards = [
        _entities_card("Status", overview_entities),
        _entities_card("Betrieb", operations_entities),
    ]
    if resource_entities:
        grid_cards.append(_entities_card("Systemressourcen", resource_entities))
    grid_cards.append(_entities_card("Dashboards", dashboards_entities))
    household_cards.append(_grid_card(grid_cards, columns=2))

    # Media overview
    if has_media:
        household_cards.append(_entities_card("Medien", media_entities))

    # Habitus zones overview
    if has_zones:
        habitus_custom_card = (
            "      - type: custom:styx-zone-card\n"
            "        entity: sensor.copilot_ha_habitus_zones\n"
            "        title: Habitus-Zonen\n"
            "        show_mood: true\n"
            "        show_neuron_activity: true\n"
            "        show_quick_actions: true\n"
        )
        household_cards.append(habitus_custom_card)
        household_cards.append(_entities_card("Zonen-Steuerung", habitus_entities))

    # HomeKit QR section (if zones)
    if has_zones:
        homekit_cards: list[str] = []
        for z in zones:
            if z.current_state == "disabled":
                continue
            qr_url = f"{core_base}/api/v1/homekit/qr/{z.zone_id}.svg"
            homekit_card = _markdown_card(
                f"HomeKit — {z.name}",
                f"![QR]({qr_url})\n\n"
                f"**Zone:** {z.name}\n"
                f"**Entities:** {len(z.entity_ids) if z.entity_ids else 0}\n\n"
                f"Scanne den QR-Code mit der Apple Home App.",
            )
            homekit_cards.append(homekit_card)

        if homekit_cards:
            household_cards.append(_grid_card(homekit_cards, columns=2))

    # Core API links
    household_cards.append(
        _markdown_card(
            "Quicklinks",
            f"**Core:** [{core_base}/health]({core_base}/health) | "
            f"[Version]({core_base}/version) | "
            f"[Events]({core_base}/api/v1/events)\n\n"
            "In YAML-Dashboards: **Generate** + Browser-Reload.",
        )
    )

    # Dev surface
    if dev_entities:
        household_cards.append(_entities_card("Entwicklung", dev_entities))

    views.append(
        _view("Haushalt", "haushalt", "mdi:home-city", "\n\n".join(household_cards))
    )

    # ── TAB 3+: PER-ZONE TABS ────────────────────────────────────────────
    # One tab per Habitus zone with detailed entity views
    if has_zones:
        from .habitus_dashboard import _lovelace_yaml_for_zone
        for z in zones:
            if z.current_state == "disabled":
                continue
            zone_view = _lovelace_yaml_for_zone(hass, z)
            views.append(zone_view)

    now = dt_util.now()
    ts = now.strftime("%Y%m%d_%H%M%S")

    content = (
        "# Generiert von PilotSuite\n"
        "# Governance-first: Diese Datei wird NICHT automatisch in Lovelace importiert.\n"
        "# In deiner YAML-Dashboard-Konfig referenzierst du die stabile `pilotsuite_dashboard_latest.yaml`.\n"
        "# Daher reicht in der Regel: **Generate** drücken + Dashboard neu laden.\n\n"
        "title: PilotSuite\n"
        "views:\n"
        + "\n".join(views)
    )

    primary_out_dir = Path(hass.config.path(PRIMARY_DASHBOARD_DIR))
    legacy_out_dir = Path(hass.config.path(LEGACY_DASHBOARD_DIR))
    out_path = primary_out_dir / f"pilotsuite_dashboard_{ts}.yaml"
    latest_path = primary_out_dir / "pilotsuite_dashboard_latest.yaml"
    legacy_latest_path = legacy_out_dir / "pilotsuite_dashboard_latest.yaml"

    await hass.async_add_executor_job(_write_text, out_path, content)
    await hass.async_add_executor_job(_write_text, latest_path, content)
    await hass.async_add_executor_job(_write_text, legacy_latest_path, content)

    st = await async_get_state(hass)
    st.last_path = str(out_path)
    await async_set_state(hass, st)

    if notify:
        persistent_notification.async_create(
            hass,
            (
                f"PilotSuite-Dashboard YAML generiert:\n{out_path}\n\n"
                f"Latest (stabil):\n{latest_path}\n\n"
                f"Legacy mirror:\n{legacy_latest_path}\n\n"
                "Hinweis: In der Regel reicht **Generate** + Browser-Reload (das Dashboard referenziert die latest-Datei)."
            ),
            title="PilotSuite Dashboard",
            notification_id="copilot_ha_pilotsuite_dashboard",
        )

    _LOGGER.info("Generated PilotSuite dashboard at %s", out_path)
    return out_path


async def async_publish_last_pilotsuite_dashboard(hass: HomeAssistant) -> str:
    st = await async_get_state(hass)

    if not st.last_path:
        raise FileNotFoundError("No PilotSuite dashboard generated yet")

    # Publish stable latest file, and keep timestamped archive locally.
    primary_dir = Path(hass.config.path(PRIMARY_DASHBOARD_DIR))
    legacy_dir = Path(hass.config.path(LEGACY_DASHBOARD_DIR))
    primary_latest = primary_dir / "pilotsuite_dashboard_latest.yaml"
    legacy_latest = legacy_dir / "pilotsuite_dashboard_latest.yaml"
    if primary_latest.exists():
        src = primary_latest
    elif legacy_latest.exists():
        src = legacy_latest
    else:
        src = Path(st.last_path)

    if not src.exists():
        raise FileNotFoundError(str(src))

    www_primary_dir = Path(hass.config.path("www")) / PRIMARY_DASHBOARD_DIR
    www_legacy_dir = Path(hass.config.path("www")) / LEGACY_DASHBOARD_DIR
    dst = www_primary_dir / "pilotsuite_dashboard_latest.yaml"
    legacy_dst = www_legacy_dir / "pilotsuite_dashboard_latest.yaml"

    await hass.async_add_executor_job(_copy, src, dst)
    await hass.async_add_executor_job(_copy, src, legacy_dst)

    st.last_published_path = str(dst)
    await async_set_state(hass, st)

    url = f"/local/{PRIMARY_DASHBOARD_DIR}/{dst.name}"
    persistent_notification.async_create(
        hass,
        (
            f"PilotSuite dashboard published (stable). Open: {url}\n\n"
            f"Legacy URL: /local/{LEGACY_DASHBOARD_DIR}/{dst.name}"
        ),
        title="PilotSuite Dashboard Download",
        notification_id="copilot_ha_pilotsuite_dashboard_download",
    )

    _LOGGER.info("Published PilotSuite dashboard to %s (url=%s)", dst, url)
    return url
