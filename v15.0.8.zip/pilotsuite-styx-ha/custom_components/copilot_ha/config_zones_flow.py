"""Zone management flow logic extracted from config_flow.py."""
from __future__ import annotations

import logging
import re
import unicodedata
from typing import Any

import voluptuous as vol

from homeassistant.core import HomeAssistant
from homeassistant.data_entry_flow import FlowResult
from homeassistant.helpers import area_registry, device_registry, entity_registry, selector
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .connection_config import build_core_headers, resolve_core_connection
from .core_endpoint import build_base_url

_LOGGER = logging.getLogger(__name__)

_MOTION_HINTS = (
    "motion",
    "presence",
    "occupancy",
    "bewegung",
    "praesenz",
    "präsenz",
    "anwesenheit",
    "pir",
    "belegt",
    "besetzt",
)


def _normalize_entity_ids(raw: Any) -> list[str]:
    if raw is None:
        return []
    if isinstance(raw, list):
        return [str(x).strip() for x in raw if str(x).strip()]
    if isinstance(raw, str):
        text = raw.strip()
        return [text] if text else []
    text = str(raw).strip()
    return [text] if text else []


def _normalize_area_ids(raw: Any) -> list[str]:
    """Normalize area selector payload to list[str]."""
    if raw is None:
        return []
    if isinstance(raw, list):
        result: list[str] = []
        seen: set[str] = set()
        for item in raw:
            value = str(item).strip()
            if not value or value in seen:
                continue
            seen.add(value)
            result.append(value)
        return result
    if isinstance(raw, str):
        value = raw.strip()
        return [value] if value else []
    value = str(raw).strip()
    return [value] if value else []


def _slugify(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value)
    ascii_text = normalized.encode("ascii", "ignore").decode("ascii")
    slug = re.sub(r"[^a-zA-Z0-9]+", "_", ascii_text).strip("_").lower()
    return slug or "zone"


def _zone_id_from_name(name: str) -> str:
    slug = _slugify(name)
    return slug if slug.startswith("zone:") else f"zone:{slug}"


def _resolve_flow_entry(flow: Any):
    """Resolve the active config entry for both legacy and reconfigure flows.

    HA 2024.4+ exposes ``_get_reconfigure_entry()`` for reconfigure flow
    contexts. Older versions only provide ``config_entry`` / ``_entry``.
    """
    get_reconfigure_entry = getattr(flow, "_get_reconfigure_entry", None)
    if callable(get_reconfigure_entry):
        try:
            entry = get_reconfigure_entry()
        except Exception:  # noqa: BLE001
            _LOGGER.debug("Failed resolving reconfigure entry", exc_info=True)
            entry = None
        else:
            if entry is not None:
                return entry

    return getattr(flow, "config_entry", None) or getattr(flow, "_entry", None)


def _ensure_unique_zone_id(candidate: str, existing_ids: set[str]) -> str:
    if candidate not in existing_ids:
        return candidate
    suffix = 2
    while True:
        probe = f"{candidate}_{suffix}"
        if probe not in existing_ids:
            return probe
        suffix += 1


def _build_zone_editor_payload(zone) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "zone_id": zone.zone_id,
        "name": zone.name,
    }
    return payload


async def _call_zone_editor_api(flow: Any, *, method: str, path: str, data: dict[str, Any] | None = None) -> dict[str, Any] | None:
    entry = _resolve_flow_entry(flow)
    if entry is None:
        return None

    try:
        host, port, token = resolve_core_connection(entry)
    except Exception as err:  # noqa: BLE001
        _LOGGER.debug("Unable to resolve Core connection for zone editor sync: %s", err)
        return None

    headers = build_core_headers(token, content_type="application/json")
    session = async_get_clientsession(flow.hass)
    url = f"{build_base_url(host, port)}{path}"

    try:
        request_kwargs: dict[str, Any] = {"headers": headers, "timeout": 10}
        if data is not None:
            request_kwargs["json"] = data

        async with session.request(method, url, **request_kwargs) as resp:
            if resp.status not in (200, 201, 204):
                response_text = await resp.text()
                _LOGGER.debug("Zone-editor call failed: %s %s (status=%s): %s", method, path, resp.status, response_text)
                return None

            if resp.status == 204:
                return {"ok": True}

            try:
                payload = await resp.json()
                if isinstance(payload, dict):
                    return payload
                return {"ok": True}
            except Exception as err:  # noqa: BLE001
                _LOGGER.debug("Non-json zone-editor response for %s %s: %s", method, path, err)
                return {"ok": True}
    except Exception as err:  # noqa: BLE001
        _LOGGER.debug("Zone-editor request failed: %s %s: %s", method, path, err)
        return None


async def async_sync_zone_editor_zone(flow: Any, *, mode: str, zone, previous_zone_id: str | None = None) -> bool:
    """Sync one zone operation with Core /api/v1/zone-editor.

    Best-effort sync: returns False on any transport/error, True only on successful Core OK reply.
    """
    if mode == "delete":
        if not previous_zone_id:
            return False
        response = await _call_zone_editor_api(
            flow,
            method="DELETE",
            path=f"/api/v1/zone-editor/zones/{previous_zone_id}",
        )
        return isinstance(response, dict) and bool(response.get("ok"))

    if zone is None:
        return False

    payload = _build_zone_editor_payload(zone)
    if mode == "create":
        response = await _call_zone_editor_api(
            flow,
            method="POST",
            path="/api/v1/zone-editor/zones",
            data=payload,
        )
        return isinstance(response, dict) and bool(response.get("ok"))

    if mode == "edit":
        response = await _call_zone_editor_api(
            flow,
            method="PUT",
            path=f"/api/v1/zone-editor/zones/{zone.zone_id}",
            data={"name": zone.name},
        )
        return isinstance(response, dict) and bool(response.get("ok"))

    return False


def _is_motion_candidate(hass: HomeAssistant, entity_id: str, reg_entry) -> bool:
    if reg_entry.domain not in ("binary_sensor", "sensor"):
        return False

    st = hass.states.get(entity_id)
    device_class = st.attributes.get("device_class") if st is not None else None
    if isinstance(device_class, str):
        if device_class.lower() in ("motion", "presence", "occupancy"):
            return True

    if isinstance(getattr(reg_entry, "device_class", None), str):
        if reg_entry.device_class.lower() in ("motion", "presence", "occupancy"):
            return True

    labels: list[str] = [entity_id.lower()]
    original_name = getattr(reg_entry, "original_name", None)
    if isinstance(original_name, str) and original_name:
        labels.append(original_name.lower())
    state_name = st.attributes.get("friendly_name") if st is not None else None
    if isinstance(state_name, str) and state_name:
        labels.append(state_name.lower())
    merged = " ".join(labels)
    return any(hint in merged for hint in _MOTION_HINTS)


def _entity_area_id(dev_reg, reg_entry) -> str | None:
    if reg_entry.area_id:
        return reg_entry.area_id
    if reg_entry.device_id:
        device = dev_reg.async_get(reg_entry.device_id)
        if device is not None:
            return device.area_id
    return None


async def _suggest_entities_for_area(hass: HomeAssistant, area_id: str) -> dict[str, list[str]]:
    """Suggest zone entities for an HA area."""
    ent_reg = entity_registry.async_get(hass)
    dev_reg = device_registry.async_get(hass)

    suggestions = {"motion": [], "lights": [], "optional": []}
    for entity_id, reg_entry in ent_reg.entities.items():
        if reg_entry.disabled_by is not None:
            continue
        if _entity_area_id(dev_reg, reg_entry) != area_id:
            continue

        domain = reg_entry.domain
        if domain == "light":
            suggestions["lights"].append(entity_id)
            continue
        if _is_motion_candidate(hass, entity_id, reg_entry):
            suggestions["motion"].append(entity_id)
            continue
        suggestions["optional"].append(entity_id)

    suggestions["motion"].sort()
    suggestions["lights"].sort()
    suggestions["optional"].sort()
    return suggestions


def _list_area_options(hass: HomeAssistant) -> list[selector.SelectOptionDict]:
    """Build deterministic area dropdown options."""
    ar = area_registry.async_get(hass)
    areas = sorted(
        ar.areas.values(),
        key=lambda area: (area.name or area.id or "").lower(),
    )
    return [
        selector.SelectOptionDict(
            value=area.id,
            label=area.name or area.id,
        )
        for area in areas
    ]


async def _suggest_entities_for_areas(hass: HomeAssistant, area_ids: list[str]) -> dict[str, list[str]]:
    """Merge suggestions for multiple areas."""
    merged = {"motion": [], "lights": [], "optional": []}
    seen: dict[str, set[str]] = {"motion": set(), "lights": set(), "optional": set()}

    for area_id in area_ids:
        suggestions = await _suggest_entities_for_area(hass, area_id)
        for key in ("motion", "lights", "optional"):
            for entity_id in suggestions.get(key, []):
                if entity_id in seen[key]:
                    continue
                seen[key].add(entity_id)
                merged[key].append(entity_id)

    return merged


def _area_name(hass: HomeAssistant, area_id: str | None) -> str:
    if not area_id:
        return ""
    ar = area_registry.async_get(hass)
    area = ar.async_get_area(area_id)
    if area is None:
        return ""
    return area.name or ""


def _build_zone_form_schema(
    *,
    mode: str,
    area_ids: list[str],
    area_options: list[selector.SelectOptionDict],
    name: str,
    motion_entity_id: str | None,
    light_entity_ids: list[str],
    optional_entity_ids: list[str],
) -> vol.Schema:
    """Build schema for create/edit zone forms."""
    fields: dict[Any, Any] = {}
    if area_options:
        fields[vol.Optional("area_ids", default=area_ids)] = selector.SelectSelector(
            selector.SelectSelectorConfig(
                options=area_options,
                multiple=True,
                mode=selector.SelectSelectorMode.DROPDOWN,
            )
        )

    fields[vol.Optional("name", default=name)] = str
    fields[vol.Optional("motion_entity_id", default=motion_entity_id)] = selector.EntitySelector(
        selector.EntitySelectorConfig(domain=["binary_sensor", "sensor"], multiple=False)
    )
    fields[vol.Optional("light_entity_ids", default=light_entity_ids)] = selector.EntitySelector(
        selector.EntitySelectorConfig(domain="light", multiple=True)
    )
    fields[vol.Optional("optional_entity_ids", default=optional_entity_ids)] = selector.EntitySelector(
        selector.EntitySelectorConfig(multiple=True)
    )
    return vol.Schema(fields)


async def create_zone_tag(hass: HomeAssistant, zone_id: str, zone_name: str) -> None:
    """Auto-create tag when zone is created."""
    try:
        from homeassistant.components import tag

        tag_id = f"aicp.place.{zone_id.replace('zone:', '')}"
        existing_tags = await tag.async_get_tags(hass)
        if tag_id not in [t.get("tag_id") for t in existing_tags.values()]:
            await tag.async_create_tag(
                hass,
                tag_id=tag_id,
                name=f"Zone: {zone_name}",
            )
            _LOGGER.info("Auto-created tag: %s for zone: %s", tag_id, zone_name)
    except Exception as ex:  # noqa: BLE001
        _LOGGER.debug("Could not auto-create tag: %s", ex)


async def tag_zone_entities(hass: HomeAssistant, zone_id: str, entity_ids: list[str]) -> None:
    """Auto-tag entities when added to zone."""
    try:
        from homeassistant.components import tag

        zone_tag = f"aicp.place.{zone_id.replace('zone:', '')}"
        for entity_id in entity_ids:
            try:
                await tag.async_tag_entity(hass, entity_id=entity_id, tag_id=zone_tag)
            except Exception:  # noqa: BLE001
                continue
        _LOGGER.info("Auto-tagged %d entities with tag: %s", len(entity_ids), zone_tag)
    except Exception as ex:  # noqa: BLE001
        _LOGGER.debug("Could not auto-tag entities: %s", ex)


async def get_zone_entity_suggestions(hass: HomeAssistant, zone_name: str) -> dict:
    """Get entity suggestions for a zone name."""
    suggestions = {
        "motion": [],
        "lights": [],
        "sensors": [],
        "media": [],
        "other": [],
    }
    zone_name_lower = zone_name.lower().replace("bereich", "").strip()
    if not zone_name_lower:
        return suggestions

    ar = area_registry.async_get(hass)
    match = next(
        (area for area in ar.areas.values() if zone_name_lower in (area.name or "").lower()),
        None,
    )
    if match is not None:
        area_suggestions = await _suggest_entities_for_area(hass, match.id)
        suggestions["motion"] = area_suggestions["motion"]
        suggestions["lights"] = area_suggestions["lights"]
        suggestions["other"] = area_suggestions["optional"]
        return suggestions

    try:
        ent_reg = entity_registry.async_get(hass)
        for entity_id, reg_entry in ent_reg.entities.items():
            if reg_entry.disabled_by is not None:
                continue
            if zone_name_lower not in entity_id.lower():
                continue
            domain = entity_id.split(".")[0]
            if domain == "light":
                suggestions["lights"].append(entity_id)
            elif domain in ("binary_sensor", "sensor") and _is_motion_candidate(hass, entity_id, reg_entry):
                suggestions["motion"].append(entity_id)
            elif domain == "sensor":
                suggestions["sensors"].append(entity_id)
            elif domain == "media_player":
                suggestions["media"].append(entity_id)
            else:
                suggestions["other"].append(entity_id)
    except Exception as ex:  # noqa: BLE001
        _LOGGER.debug("Could not get zone suggestions: %s", ex)

    return suggestions


async def async_step_reconfigure(flow, user_input: dict | None = None) -> FlowResult:
    """Compatibility entrypoint for HA >= 2024.4 reconfigure flow.

    Reconfigure flows populate the target entry through ``_get_reconfigure_entry``
    in recent Home Assistant versions. We resolve it here and route into the
    normal options menu/entry point.
    """
    entry = _resolve_flow_entry(flow)
    if entry is None:
        return flow.async_abort(reason="no_entry")

    if getattr(flow, "_entry", None) != entry:
        try:
            setattr(flow, "_entry", entry)
        except Exception:  # noqa: BLE001
            pass

    if hasattr(flow, "async_step_init"):
        return await flow.async_step_init(user_input)
    if hasattr(flow, "async_step_habitus_zones"):
        return await flow.async_step_habitus_zones()
    return flow.async_abort(reason="cannot_reconfigure")


async def async_step_zone_form(
    flow,
    *,
    mode: str,
    user_input: dict | None,
    zone_id: str | None = None,
) -> FlowResult:
    """Handle zone create/edit form (extracted from OptionsFlowHandler)."""
    from .habitus_zones_store_v2 import HabitusZoneV2, async_get_zones_v2, async_set_zones_v2

    entry = _resolve_flow_entry(flow)
    if entry is None:
        return flow.async_abort(reason="no_entry")

    zones = await async_get_zones_v2(flow.hass, entry.entry_id)
    existing = {z.zone_id: z for z in zones}

    zone = existing.get(zone_id) if zone_id else None
    if mode == "edit" and zone is None:
        return flow.async_abort(reason="no_zones")

    step_id = "create_zone" if mode == "create" else "edit_zone_form"

    area_options = _list_area_options(flow.hass)
    default_area_ids: list[str] = []
    default_name = ""
    default_motion: str | None = None
    default_lights: list[str] = []
    default_optional: list[str] = []

    if zone is not None:
        default_name = zone.name or ""
        metadata = zone.metadata if isinstance(zone.metadata, dict) else {}
        default_area_ids = _normalize_area_ids(metadata.get("ha_area_ids"))
        if not default_area_ids and metadata.get("ha_area_id"):
            default_area_ids = _normalize_area_ids(metadata.get("ha_area_id"))
        ent_map = getattr(zone, "entities", None)
        if isinstance(ent_map, dict):
            motion_list = _normalize_entity_ids(ent_map.get("motion"))
            lights_list = _normalize_entity_ids(ent_map.get("lights"))
            other_list = _normalize_entity_ids(ent_map.get("other"))
            default_motion = motion_list[0] if motion_list else None
            default_lights = lights_list
            default_optional = other_list
        else:
            for eid in zone.entity_ids:
                if eid.startswith("light."):
                    default_lights.append(eid)
                elif eid.startswith(("binary_sensor.", "sensor.")) and default_motion is None:
                    default_motion = eid
                else:
                    default_optional.append(eid)

    if user_input is None:
        schema = _build_zone_form_schema(
            mode=mode,
            area_ids=default_area_ids,
            area_options=area_options,
            name=default_name,
            motion_entity_id=default_motion,
            light_entity_ids=default_lights,
            optional_entity_ids=default_optional,
        )
        return flow.async_show_form(step_id=step_id, data_schema=schema)

    area_ids = _normalize_area_ids(user_input.get("area_ids"))
    if not area_ids:
        # Backward compatibility for old payloads.
        area_ids = _normalize_area_ids(user_input.get("area_id"))
    if not area_ids and mode == "edit":
        area_ids = list(default_area_ids)

    name = str(user_input.get("name") or "").strip()
    motion = str(user_input.get("motion_entity_id") or "").strip()
    lights = _normalize_entity_ids(user_input.get("light_entity_ids"))
    optional = _normalize_entity_ids(user_input.get("optional_entity_ids"))

    auto_hint = ""
    if area_ids and (not motion or not lights):
        suggestions = await _suggest_entities_for_areas(flow.hass, area_ids)
        if not motion and suggestions["motion"]:
            motion = suggestions["motion"][0]
            auto_hint = "Motion wurde automatisch aus dem gewählten Bereich übernommen."
        if not lights and suggestions["lights"]:
            lights = suggestions["lights"]
            if auto_hint:
                auto_hint = f"{auto_hint} Lichter wurden ebenfalls automatisch übernommen."
            else:
                auto_hint = "Lichter wurden automatisch aus dem gewählten Bereich übernommen."
        if not optional:
            optional = suggestions["optional"][:8]

    area_names = [name for name in (_area_name(flow.hass, aid) for aid in area_ids) if name]
    area_name_summary = " + ".join(area_names) if area_names else ""

    if mode == "edit" and zone is not None:
        zid = zone.zone_id
        zone_name = name or zone.name or zid
    else:
        base_name = name or area_name_summary or "Zone"
        zid = _zone_id_from_name(base_name)
        zid = _ensure_unique_zone_id(zid, set(existing))
        zone_name = base_name

    errors: dict[str, str] = {}
    if not motion and not lights and not optional:
        errors["base"] = "invalid"
    if errors:
        schema = _build_zone_form_schema(
            mode=mode,
            area_ids=area_ids,
            area_options=area_options,
            name=name,
            motion_entity_id=motion or None,
            light_entity_ids=lights,
            optional_entity_ids=optional,
        )
        missing_hint = "Bitte mindestens eine Entitaet auswaehlen (Motion, Licht oder optional)."
        combined_hint = f"{auto_hint} {missing_hint}".strip() if auto_hint else missing_hint
        placeholders = {"hint": combined_hint}
        return flow.async_show_form(
            step_id=step_id,
            data_schema=schema,
            errors=errors,
            description_placeholders=placeholders,
        )

    entity_ids = [motion] + lights + optional
    uniq: list[str] = []
    seen: set[str] = set()
    for entity_id in entity_ids:
        if not entity_id or entity_id in seen:
            continue
        seen.add(entity_id)
        uniq.append(entity_id)

    ent_map = {"motion": [motion], "lights": lights, "other": optional}
    ent_map = {key: value for key, value in ent_map.items() if value}
    base_metadata = dict(zone.metadata) if zone is not None and isinstance(zone.metadata, dict) else {}
    if area_ids:
        base_metadata["ha_area_ids"] = area_ids
    else:
        base_metadata.pop("ha_area_ids", None)
    base_metadata.pop("ha_area_id", None)

    new_zone = HabitusZoneV2(
        zone_id=zid,
        name=zone_name or zid,
        entity_ids=tuple(uniq),
        entities=ent_map or None,
        metadata=base_metadata or None,
    )

    replace_zone_id = zone.zone_id if zone is not None else zid
    new_list = [existing_zone for existing_zone in zones if existing_zone.zone_id != replace_zone_id]
    new_list.append(new_zone)

    try:
        await async_set_zones_v2(flow.hass, entry.entry_id, new_list)
    except ValueError as err:
        _LOGGER.debug("Zone validation failed for %s: %s", zid, err)
        schema = _build_zone_form_schema(
            mode=mode,
            area_ids=area_ids,
            area_options=area_options,
            name=name,
            motion_entity_id=motion or None,
            light_entity_ids=lights,
            optional_entity_ids=optional,
        )
        placeholders = {"hint": f"{auto_hint} {err}".strip()} if auto_hint else {"hint": str(err)}
        return flow.async_show_form(
            step_id=step_id,
            data_schema=schema,
            errors={"base": "invalid"},
            description_placeholders=placeholders,
        )

    sync_mode = "create" if mode == "create" else "edit"
    synced = await async_sync_zone_editor_zone(flow, mode=sync_mode, zone=new_zone)
    if not synced:
        _LOGGER.debug("Zone-editor sync not confirmed for %s (%s)", zid, sync_mode)

    await create_zone_tag(flow.hass, zid, zone_name)
    await tag_zone_entities(flow.hass, zid, uniq)
    return await flow.async_step_habitus_zones()
