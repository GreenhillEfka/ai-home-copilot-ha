"""Entity Tags Module — manual + automatic entity tagging for PilotSuite.

Provides a way for users to assign custom tags to HA entities, enabling
modules to query "give me all entities tagged as Licht" instead of blindly
scanning all entities.

Features:
- Manual tagging via config flow UI
- Auto "Styx" tagging: every entity Styx interacts with gets auto-tagged
- User-labeled "Styx" entities are monitored by PilotSuite
- Tags visible in LLM context, sensors, and queryable by modules
"""
from __future__ import annotations

import logging
from typing import Any, Optional

from homeassistant.core import HomeAssistant

from .module import CopilotModule, ModuleContext

_LOGGER = logging.getLogger(__name__)

STYX_TAG_ID = "styx"
STYX_TAG_NAME = "Styx"
STYX_TAG_COLOR = "#8b5cf6"  # Purple
STYX_TAG_ICON = "mdi:robot"


class EntityTagsModule(CopilotModule):
    """Module managing user-defined and auto-generated entity tags."""

    @property
    def name(self) -> str:
        return "entity_tags"

    @property
    def version(self) -> str:
        return "0.2.0"

    def __init__(self):
        self._tags: dict = {}   # tag_id -> EntityTag
        self._hass: Optional[HomeAssistant] = None
        self._entry_id: Optional[str] = None

    async def async_setup_entry(self, ctx: ModuleContext) -> None:
        """Load tags from storage and register in hass.data."""
        self._hass = ctx.hass
        self._entry_id = ctx.entry_id

        from ...entity_tags_store import async_get_entity_tags
        self._tags = await async_get_entity_tags(ctx.hass)

        ctx.hass.data.setdefault("copilot_ha", {})
        ctx.hass.data["copilot_ha"].setdefault(ctx.entry_id, {})
        ctx.hass.data["copilot_ha"][ctx.entry_id]["entity_tags_module"] = self

        # Auto-create neuron tags for existing zones if none exist yet.
        # This ensures zones created before v14.4.x get neuron tags on upgrade.
        has_neuron_tags = any(tid.startswith("neuron_") for tid in self._tags)
        if not has_neuron_tags:
            await self._ensure_neuron_tags(ctx)

        # Sync all tags (including neuron tags) to Core so Core knows
        # which entities feed which neuron layers.
        await self._sync_tags_to_core_safe()

        _LOGGER.info(
            "EntityTagsModule setup: %d tags loaded",
            len(self._tags),
        )

    async def _ensure_neuron_tags(self, ctx: ModuleContext) -> None:
        """Create neuron tags from existing habitus zones (one-time migration)."""
        try:
            from ...habitus_zones_store_v2 import async_get_zones_v2
            from ...zone_auto_setup import async_create_neuron_tags_from_zones

            zones = await async_get_zones_v2(ctx.hass, ctx.entry_id)
            if not zones:
                _LOGGER.debug("No habitus zones found, skipping neuron tag creation")
                return

            neuron_map = await async_create_neuron_tags_from_zones(ctx.hass, zones)
            _LOGGER.info(
                "Neuron tags auto-created for %d existing zones: "
                "%d context, %d state, %d mood",
                len(zones),
                len(neuron_map.get("context", [])),
                len(neuron_map.get("state", [])),
                len(neuron_map.get("mood", [])),
            )
            # Reload tags so this module has the fresh state
            from ...entity_tags_store import async_get_entity_tags
            self._tags = await async_get_entity_tags(ctx.hass)

        except Exception:  # noqa: BLE001
            _LOGGER.debug("Could not auto-create neuron tags from zones", exc_info=True)

    async def async_unload_entry(self, ctx: ModuleContext) -> bool:
        entry_store = ctx.hass.data.get("copilot_ha", {}).get(ctx.entry_id, {})
        if isinstance(entry_store, dict):
            entry_store.pop("entity_tags_module", None)
        return True

    # ------------------------------------------------------------------
    # Public read API (sync — safe to call from sensors/modules)
    # ------------------------------------------------------------------

    def get_all_tags(self) -> list:
        """Return all EntityTag objects."""
        return list(self._tags.values())

    def get_entities_by_tag(self, tag_id: str) -> list[str]:
        """Return entity_ids that have the given tag."""
        tag = self._tags.get(tag_id)
        return list(tag.entity_ids) if tag else []

    def get_styx_entities(self) -> list[str]:
        """Return all entities tagged with 'Styx'."""
        return self.get_entities_by_tag(STYX_TAG_ID)

    def get_tags_for_entity(self, entity_id: str) -> list:
        """Return all tags that include this entity_id."""
        return [t for t in self._tags.values() if entity_id in t.entity_ids]

    def is_styx_entity(self, entity_id: str) -> bool:
        """Check if an entity is tagged with 'Styx'."""
        tag = self._tags.get(STYX_TAG_ID)
        return tag is not None and entity_id in tag.entity_ids

    def get_tag_count(self) -> int:
        return len(self._tags)

    def get_total_tagged_entities(self) -> int:
        """Total unique entities across all tags."""
        all_ids: set[str] = set()
        for tag in self._tags.values():
            all_ids.update(tag.entity_ids)
        return len(all_ids)

    def get_summary(self) -> dict[str, Any]:
        """Structured summary for sensor attributes."""
        styx_count = len(self.get_styx_entities())
        return {
            "tag_count": len(self._tags),
            "styx_tagged_count": styx_count,
            "tags": [
                {
                    "tag_id": t.tag_id,
                    "name": t.name,
                    "entity_count": len(t.entity_ids),
                    "color": t.color,
                    "icon": t.icon,
                }
                for t in self._tags.values()
            ],
        }

    # ------------------------------------------------------------------
    # Mutation API (async — persists to storage)
    # ------------------------------------------------------------------

    async def reload_from_storage(self) -> None:
        """Re-read tags from HA Storage (call after config flow saves)."""
        if self._hass:
            from ...entity_tags_store import async_get_entity_tags
            self._tags = await async_get_entity_tags(self._hass)
            _LOGGER.debug("EntityTagsModule reloaded: %d tags", len(self._tags))

    async def async_auto_tag_styx(self, entity_ids: list[str]) -> int:
        """Auto-tag entities with 'Styx' when Styx interacts with them.

        Called by tool execution, scene application, automation creation, etc.
        Returns the number of newly tagged entities.
        """
        if not self._hass or not entity_ids:
            return 0

        from ...entity_tags_store import async_upsert_tag

        current = self.get_styx_entities()
        new_ids = [eid for eid in entity_ids if eid not in current]
        if not new_ids:
            return 0

        merged = list(set(current + new_ids))
        await async_upsert_tag(
            self._hass,
            tag_id=STYX_TAG_ID,
            name=STYX_TAG_NAME,
            entity_ids=merged,
            color=STYX_TAG_COLOR,
            icon=STYX_TAG_ICON,
            module_hints=["pilotsuite", "monitoring"],
        )
        await self.reload_from_storage()
        _LOGGER.info("Auto-tagged %d entities with Styx (total: %d)", len(new_ids), len(merged))
        # Push updated tags to Core
        await self._sync_tags_to_core_safe()
        return len(new_ids)

    # ------------------------------------------------------------------
    # Core Tag Sync (bidirectional: HA ↔ Core)
    # ------------------------------------------------------------------

    async def async_sync_tags_to_core(self) -> int:
        """Push local HA entity tags to Core for bidirectional sync.

        Returns number of tags synced.
        """
        if not self._hass or not self._entry_id:
            return 0

        coordinator = self._get_coordinator()
        if not coordinator:
            return 0

        tags_payload = [
            {
                "tag_id": t.tag_id,
                "name": t.name,
                "entity_ids": list(t.entity_ids),
                "color": t.color,
                "icon": t.icon,
                "module_hints": list(t.module_hints),
            }
            for t in self._tags.values()
        ]

        result = await coordinator.api.async_sync_tags_to_core(tags_payload)
        synced = result.get("synced", 0)
        _LOGGER.info("Synced %d entity tags to Core", synced)
        return synced

    async def async_sync_tags_to_zones(self) -> int:
        """Bridge entity tags into HabitusZones — entities with matching zone
        tags get linked to zones.

        Returns number of zone-entity associations discovered.
        """
        if not self._hass or not self._entry_id:
            return 0

        from ...habitus_zones_store_v2 import async_get_zones_v2

        zones = await async_get_zones_v2(self._hass, self._entry_id)
        if not zones:
            return 0

        updates = 0
        for tag in self._tags.values():
            for zone in zones:
                if tag.tag_id in zone.tags:
                    current_entities = set(zone.entity_ids)
                    new_entities = set(tag.entity_ids) - current_entities
                    if new_entities:
                        updates += len(new_entities)
                        _LOGGER.debug(
                            "Zone %s: %d new entities from tag %s",
                            zone.zone_id,
                            len(new_entities),
                            tag.tag_id,
                        )

        return updates

    async def _sync_tags_to_core_safe(self) -> None:
        """Best-effort sync of tags to Core. Swallows errors so setup never fails."""
        try:
            synced = await self.async_sync_tags_to_core()
            if synced:
                _LOGGER.info("Tag sync to Core: %d tags pushed", synced)
        except Exception:  # noqa: BLE001
            _LOGGER.debug("Tag sync to Core deferred (Core may not be reachable yet)")

    def _get_coordinator(self):
        """Get the CopilotDataUpdateCoordinator instance."""
        if not self._hass or not self._entry_id:
            return None
        entry_data = self._hass.data.get("copilot_ha", {}).get(self._entry_id, {})
        return entry_data.get("coordinator")

    # ------------------------------------------------------------------
    # LLM Context
    # ------------------------------------------------------------------

    def get_context_for_llm(self) -> str:
        """Inject tag info into LLM system prompt."""
        if not self._tags:
            return ""
        lines = ["Manuelle Entitäts-Tags:"]
        for tag in self._tags.values():
            if not tag.entity_ids:
                continue
            sample = tag.entity_ids[:5]
            suffix = " …" if len(tag.entity_ids) > 5 else ""
            marker = " [auto]" if tag.tag_id == STYX_TAG_ID else ""
            lines.append(f"  [{tag.name}]{marker}: {', '.join(sample)}{suffix}")
        styx_count = len(self.get_styx_entities())
        if styx_count > 0:
            lines.append(f"  Styx hat insgesamt {styx_count} Entitäten berührt.")
        return "\n".join(lines) if len(lines) > 1 else ""


def get_entity_tags_module(hass: HomeAssistant, entry_id: str) -> Optional[EntityTagsModule]:
    """Return the EntityTagsModule instance for a config entry, or None."""
    data = hass.data.get("copilot_ha", {}).get(entry_id, {})
    return data.get("entity_tags_module")
